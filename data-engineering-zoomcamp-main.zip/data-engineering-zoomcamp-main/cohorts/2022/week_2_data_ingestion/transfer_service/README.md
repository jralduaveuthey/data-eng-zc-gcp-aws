## Generate AWS Access key
- Login in to AWS account  
- Search for IAM
  ![aws iam](../../images/aws/iam.png)
- Click on `Manage access key`
- Click on `Create New Access Key`
- Download the csv, your access key and secret would be in that csv (Please note that once lost secret cannot be recovered)

## Transfer service
https://console.cloud.google.com/transfer/cloud/jobs


