
![](images/architecture/arch_1.jpg)
